#!/usr/bin/env python3
"""轻量 Kotlin 静态检查（在 CI 之前抓最常见的编译错）
  1) 去掉注释/字符串后检查 {} () [] 配平
  2) 字符串里禁止 $( （这是 Kotlin 里常见的 shell 转义漏写 → 直接编译错）
  3) 列出普通 $标识符 供人工确认（默认允许 HOME/TAG 这类刻意的常量插值）
用法: python3 kotlin_lint.py <文件.kt> [允许的模板变量,逗号分隔]
"""
import re, sys
p = sys.argv[1]
allow = set((sys.argv[2] if len(sys.argv) > 2 else "HOME,TAG").split(','))
s = open(p).read()

def strip(src):
    out=[];i=0;n=len(src)
    while i<n:
        c=src[i]
        if c=='/' and i+1<n and src[i+1]=='/':
            j=src.find('\n',i); i=n if j<0 else j; continue
        if c=='/' and i+1<n and src[i+1]=='*':
            j=src.find('*/',i+2); i=n if j<0 else j+2; continue
        if c=='"':
            i+=1
            while i<n and src[i]!='"':
                if src[i]=='\\': i+=1
                i+=1
            i+=1; out.append('S'); continue
        out.append(c); i+=1
    return ''.join(out)

t = strip(s); bad = 0; manual = []
for a,b in [('{','}'),('(',')'),('[',']')]:
    if t.count(a)!=t.count(b):
        print("✗ 括号不配平 %s%s (%d/%d)"%(a,b,t.count(a),t.count(b))); bad += 1
for ln,line in enumerate(s.split('\n'),1):
    if '\\$(' in line: continue
    if '$(' in line and '"' in line:
        print("✗ 第%d行 字符串里出现 $( ，必须写成 \\$( ：%s"%(ln,line.strip()[:70])); bad += 1
    for m in re.finditer(r'\$([A-Za-z_][A-Za-z0-9_]*)', line):
        if line[max(0,m.start()-1):m.start()]=='\\': continue
        if m.group(1) in allow: continue
        manual.append((ln,m.group(0),line.strip()[:60]))
print("人工确认的 $模板（非错误，确认是刻意的即可）：")
for x in manual: print("  第%d行 %s | %s"%x)
print("结论：", "无硬错误 ✓" if bad==0 else "有 %d 处硬错误 ✗"%bad)
