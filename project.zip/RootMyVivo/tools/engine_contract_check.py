#!/usr/bin/env python3
"""引擎契约自测（CI 用）：不运行引擎，只把它当黑盒核对契约。
   检查项：① 引擎存在且是 aarch64 ET_DYN ② 引擎支持我们用的入口参数
           ③ 内嵌脚本长度/占位符/语法/关键特性 ④ 六个载荷齐全 ⑤ 内置 profile 的 sha256
   任何一项失败 → 退出码非 0（CI 变红，不会带上真机）
"""
import sys, os, hashlib, subprocess

FAIL = []
def ck(ok, msg):
    print(("  ✓ " if ok else "  ✗ ") + msg)
    if not ok: FAIL.append(msg)

root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
J = 15607          # 引擎里的脚本注入偏移
LIMIT = 6115       # 模板区容量
PROFILE_SHA = "9a3bfaac816d0822783b3d7cd84cf9bb220cf42cc29e75300bdba60b4eadfa6d"
PROFILE_BIN_SHA = "e330d15c70fd97125e9a3af6f12407a459218921db88672e4963ec6625ac7f23"

print("== ① 引擎 ==")
E = os.path.join(root, "app/src/main/jniLibs/arm64-v8a/libglk_engine.so")
if not os.path.exists(E):
    ck(False, "引擎载体存在"); sys.exit(1)
d = open(E, "rb").read()
ck(len(d) == 240824, f"引擎大小 240824（实际 {len(d)}）")
ck(d[:4] == b"\x7fELF", "ELF 魔数")
ck(d[16] == 3, "ELF 类型 ET_DYN")
ck(int.from_bytes(d[18:20], "little") == 0xB7, "机器码 aarch64")
ck(b"ghostlock-app-call" in d, "引擎支持 --ghostlock-app-call")
ck(b"load-prebuilt-profile" in d, "引擎支持 --load-prebuilt-profile")
ck(b"GHOSTLOCK_HOME" in d, "引擎从环境变量 GHOSTLOCK_HOME 取工作目录")
ck(b"GHOSTLOCK_KSU_LOG" in d, "引擎支持 GHOSTLOCK_KSU_LOG")

print("== ② 内嵌脚本 ==")
end = d.find(b"\x00", J)
sc = d[J:end]
ck(0 < len(sc) <= LIMIT, f"脚本长度 {len(sc)} ≤ {LIMIT}")
ck(sc.count(b"%") == 4, f"占位符 % 恰好 4 个（实际 {sc.count(b'%')}）")
txt = sc.decode(errors="replace")
for k in ["GLK_BIN", "GLK_LIB", "===== verify =====", "glk_tail.log", "ksud", "atcid_vendor_socket"]:
    ck(k in txt, f"脚本含关键片段 {k}")
open("/tmp/_sc.sh", "w").write(txt)
r = subprocess.run(["sh", "-n", "/tmp/_sc.sh"], capture_output=True)
ck(r.returncode == 0, "脚本 sh -n 语法通过")

print("== ③ 载荷 ==")
lib = os.path.join(root, "app/src/main/jniLibs/arm64-v8a")
for f in ["libwk_a0.so","libwk_b0.so","libwk_b1.so","libwk_c1.so","libwk_c2.so","libwk_d0.so"]:
    ck(os.path.exists(os.path.join(lib, f)), f"载荷 {f}")

print("== ④ 内置 profile ==")
P = os.path.join(root, "app/src/main/assets/glk/profile.conf")
if os.path.exists(P):
    ck(hashlib.sha256(open(P, "rb").read()).hexdigest() == PROFILE_SHA,
       "profile.conf 与 v38 成功版逐位一致")
else:
    ck(False, "assets/glk/profile.conf 存在")

print("== ④b 内置 profile.bin ==")
PB = os.path.join(root, "app/src/main/assets/glk/profile.bin")
if os.path.exists(PB):
    ck(hashlib.sha256(open(PB, "rb").read()).hexdigest() == PROFILE_BIN_SHA,
       "profile.bin 与 v38 成功版逐位一致")
else:
    ck(False, "assets/glk/profile.bin 存在")

print("== ⑤ 挂钩 ==")
ENG = os.path.join(root, "app/src/main/java/com/rootmyvivo/root/ExploitEngine.kt")
s = open(ENG).read() if os.path.exists(ENG) else ""
ck("GlkChain.isBuiltIn" in s and "GlkChain.run" in s, "ExploitEngine.run() 顶部已挂钩 GlkChain")
GLK = os.path.join(root, "app/src/main/java/com/rootmyvivo/root/GlkChain.kt")
g = open(GLK).read() if os.path.exists(GLK) else ""
ck("nativeLibraryDir" in g, "载体来源 = APK 原生库目录")
ck("home.listFiles()?.forEach" in g, "启动前清空工作目录")
ck("listOf(\"profile.conf\", \"profile.bin\")" in g, "成对写入 profile.conf + profile.bin")
ck("GHOSTLOCK_HOME" in g, "启动引擎时传入 GHOSTLOCK_HOME")

print()
if FAIL:
    print(f"契约自测失败：{len(FAIL)} 项 ✗")
    for f in FAIL: print("   -", f)
    sys.exit(1)
print("契约自测全部通过 ✓")
