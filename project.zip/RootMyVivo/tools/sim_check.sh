#!/bin/bash
# 用桩命令"干跑"引擎内嵌的合并脚本：验证成功路径 / 闸门超时路径的控制流。
# 不接触真机、不执行任何漏洞利用。
set -e
D=$(mktemp -d); mkdir -p "$D/bin" "$D/wk"
python3 - "$D" <<'PY'
import sys, os, re
d=sys.argv[1]
eng=os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),'app/src/main/jniLibs/arm64-v8a/libglk_engine.so')
data=open(eng,'rb').read(); J=15607
sc=data[J:data.find(b'\x00',J)].decode()
out = sc % (d+'/wk', d+'/wk/ksu.log', 0, d+'/debug')      # 引擎的格式化方式
out = out.replace('/data/local/tmp/ghostlock-app', d+'/wk').replace('/data/local/tmp', d+'/wk')
out = out.replace('/system/bin/sh','sh').replace('/system/bin/','')
open(d+'/wk/.ghostlock_root.sh','w').write(out)
assert out.count('%')==0, "格式化后仍有未替换占位符"
PY
for c in sleep pidof kill pkill; do printf '#!/bin/sh\n:\n' > "$D/bin/$c"; done
printf '#!/bin/sh\ncase "$*" in *-u*) echo 2000;; *) echo "uid=0(root) context=u:r:ksu:s0";; esac\n' > "$D/bin/id"
printf '#!/bin/sh\necho Permissive\n' > "$D/bin/getenforce"
printf '#!/bin/sh\necho "Starting: Intent { cmp=me.weishu.kernelsu/.ui.MainActivity }"\n' > "$D/bin/am"
printf '#!/bin/sh\necho "Events injected: 1"\n' > "$D/bin/monkey"
printf '#!/bin/sh\necho "posting: 0"\n' > "$D/bin/cmd"
printf '#!/bin/sh\ncase "$2" in *GLC=*) echo "uid=0(root) context=u:r:atcid_vendor:s0"; echo GLC=0;; *getenforce*) echo "uid=0(root) context=u:r:atcid_vendor:s0"; echo Permissive; echo 1;; *) echo "uid=0(root) context=u:r:atcid_vendor:s0";; esac\n' > "$D/bin/b0"
cp "$D/bin/b0" "$D/wk/b0"; chmod +x "$D/bin"/* "$D/wk/b0"

echo "▶ 场景① 成功路径"
PATH="$D/bin:$PATH" sh "$D/wk/.ghostlock_root.sh"; rc=$?
grep -q "root channel ready" "$D/wk/ksu.log" && echo "  通道就绪 ✓" || { echo "  ✗ 未走到通道"; exit 1; }
grep -q "===== verify =====" "$D/wk/ksu.log" && echo "  verify 段出现 ✓" || { echo "  ✗ 没有 verify"; exit 1; }

echo "▶ 场景② 闸门超时（SELinux 一直 Enforcing）"
printf '#!/bin/sh\necho Enforcing\n' > "$D/bin/getenforce"; chmod +x "$D/bin/getenforce"
rm -f "$D/wk/ksu.log"
PATH="$D/bin:$PATH" sh "$D/wk/.ghostlock_root.sh" || true
grep -q "gate timeout" "$D/wk/ksu.log" && echo "  立刻失败并退出 ✓" || { echo "  ✗ 未按预期快失败"; exit 1; }
echo "脚本控制流自测通过 ✓"
