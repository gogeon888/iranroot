package com.rootmyvivo.root

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile

/**
 * 内置流程：GhostLock 引擎 + 无痕一键root 载荷链 + 已验证的合并脚本（依然一键root 整合版 v4）
 *
 * 关键修正（v3 → v4）：**改为 App 本地执行**，不再要求 shell 通道。
 *   · 该外壳（RootMyVivo）的设计本就是从 App 里直接跑（它的注释写明"首次运行不需要 Shizuku/ADB"），
 *     它的 Transport.exec 是纯 ADB 且要求 firstRootDone —— 首次必然拿不到 shell。
 *   · 所以本链全部在 App 进程内完成：
 *       1. 把载体（引擎 + 6 个载荷）从 APK 原生库目录复制到 filesDir/glk 并设为 0555（可执行、不可写）
 *       2. 直接以 App 身份启动引擎（引擎硬编码 HOME=/data/local/tmp/ghostlock-app，0777 可写）
 *       3. 轮询引擎生成的 .ghostlock_root.sh，用 sh 执行，并把 GLK_BIN 指向 filesDir/glk
 *          （脚本内所有载荷调用已参数化为 $B = ${GLK_BIN:-$WK}）
 *       4. 成功判定：读脚本自己打印的 verify 段（uid=0 + Permissive）
 */
object GlkChain {

    private const val TAG = "GlkChain"
    const val HOME = "/data/local/tmp/ghostlock-app"

    private val BUILT_IN_KERNELS = listOf(
        "5.15.149-android13-8-gf81de23b360f-dirty",
    )

    /** APK 原生库目录里的载体名 → filesDir/glk 下的真实名字 */
    private val CARRIERS = listOf(
        "libglk_engine.so" to "libgl_real.so",
        "libwk_a0.so"      to "a0",
        "libwk_b0.so"      to "b0",
        "libwk_b1.so"      to "b1",
        "libwk_c1.so"      to "c1",
        "libwk_c2.so"      to "c2",
        "libwk_d0.so"      to "d0",
    )

    private fun kernelLine(): String = try {
        val p = ProcessBuilder("/system/bin/sh", "-c", "uname -r").redirectErrorStream(true).start()
        val s = p.inputStream.bufferedReader().readText().trim()
        p.waitFor(); s
    } catch (_: Exception) { "" }

    fun isBuiltIn(ctx: Context): Boolean {
        val k = kernelLine()
        val hit = BUILT_IN_KERNELS.any { k == it || k.startsWith(it) }
        Log.i(TAG, "isBuiltIn: kernel=$k hit=$hit")
        return hit
    }

    private fun tail(f: File, bytes: Int = 20000): String = try {
        RandomAccessFile(f, "r").use { raf ->
            val len = raf.length()
            val start = if (len > bytes) len - bytes else 0L
            raf.seek(start)
            val buf = ByteArray((len - start).toInt())
            raf.readFully(buf)
            String(buf)
        }
    } catch (_: Exception) { "" }

    /** 部署载体到 App 私有目录（可执行、不可写 —— 满足 W^X） */
    private fun deployCarriers(ctx: Context, log: suspend (String) -> Unit): File? {
        val binDir = File(ctx.filesDir, "glk").apply { mkdirs() }
        val libDir = File(ctx.applicationInfo.nativeLibraryDir)
        for ((from, to) in CARRIERS) {
            val src = File(libDir, from)
            if (!src.exists()) { Log.w(TAG, "缺少载体 $from"); return null }
            val dst = File(binDir, to)
            src.copyTo(dst, overwrite = true)
            dst.setReadable(true, false)
            dst.setExecutable(true, false)
            dst.setWritable(false, false)
        }
        return binDir
    }

    /**
     * 跑完整内置流程（全部在 App 进程内）。返回 true = verify 通过。
     */
    suspend fun run(ctx: Context, log: suspend (String) -> Unit): Boolean = withContext(Dispatchers.IO) {
        val binDir = deployCarriers(ctx, log)
        if (binDir == null) { log("[!] 内置零件缺失（APK 里没找到载体）"); return@withContext false }

        val home = File(HOME)
        if (!home.exists() && !home.mkdirs()) { log("[!] 无法创建 $HOME"); return@withContext false }
        // 全量清理：目录是 0777，可删除任何 uid 的旧文件。
        // 必须全删 —— 否则旧安装（不同 uid）留下的 .glk_engine_app.log / bg.pid 是 0600，
        // 新安装写不进去，sh 的重定向会失败，导致后台命令根本不执行。
        home.listFiles()?.forEach { f ->
            if (!f.delete()) Log.w(TAG, "无法删除残留 ${f.name}")
        }

        // 内置参数：把随包携带的 profile 写进工作目录（与 GhostLock 原 App 做法一致：
        // 它会把 runtime profile 写成 profile.conf / profile.bin 后，再以 --ghostlock-app-call 启动引擎）
        listOf("profile.conf").forEach { n ->
            try {
                ctx.assets.open("glk/$n").use { i -> File(home, n).outputStream().use { o -> i.copyTo(o) } }
            } catch (e: Exception) { Log.i(TAG, "assets/glk/$n 缺失：${e.message}") }
        }

        // 引擎：App 本地启动，参数与 GhostLock 原 App 完全一致
        val engine = File(binDir, "libgl_real.so")
        LocalRunner.execBackground(
            engine.absolutePath + " --ghostlock-app-call --enable-status-record",
            mapOf("GLK_BIN" to binDir.absolutePath),
            File(home, ".glk_engine_app.log")
        )
        log("[*] 引擎已启动（App 本地方式）")

        var scriptStarted = false
        var printed = 0
        var ok = false
        val script = File(home, ".ghostlock_root.sh")

        for (i in 1..240) {                     // 最多 ~10 分钟
            delay(2500)
            if (!scriptStarted && script.exists() && script.length() > 0) {
                LocalRunner.execBackground(
                    "/system/bin/sh " + script.absolutePath,
                    mapOf("GLK_BIN" to binDir.absolutePath),
                    File(home, ".glk_script_app.log")
                )
                scriptStarted = true
                log("[*] 脚本已生成，开始执行越狱链")
            }
            val newest = home.listFiles { f -> f.name.startsWith("ghostlock-ksu-") }
                ?.maxByOrNull { it.lastModified() }
            val body = if (newest != null) tail(newest) else ""
            val lines = body.lineSequence().filter { it.isNotBlank() }.toList()
            if (lines.size > printed) { lines.drop(printed).forEach { log(it) }; printed = lines.size }

            val afterVerify = body.substringAfter("===== verify =====", "")
            if (afterVerify.contains("uid=0(root)") && afterVerify.contains("Permissive")) {
                ok = true
                log("[+] verify 通过：root 已生效（uid=0 / Permissive）")
                break
            }
            if (body.contains("失败:")) { log("[!] 脚本报告失败（可再点一次，漏洞利用有概率性）"); break }
            if (!scriptStarted && i == 24) log("[!] 引擎尚未生成脚本（这次漏洞利用没打穿），可再点一次")
            if (i % 12 == 0) log("[*] 进行中…（${i * 5 / 2}s）")
        }
        if (!ok && scriptStarted) log("[!] 未在时限内完成（可再点一次）")
        ok
    }

    /** root 还活着时只补拉起 KernelSU（PowerShell 不参与：纯 am start） */
    suspend fun onlyLaunchKsu(ctx: Context, log: suspend (String) -> Unit) = withContext(Dispatchers.IO) {
        log("[*] 已有 root，仅拉起 KernelSU")
        repeat(3) {
            delay(2500)
            LocalRunner.exec("/system/bin/sh -c 'am start -n me.weishu.kernelsu/.ui.MainActivity -f 0x10200000'", emptyMap(), 20)
        }
        Unit
    }
}
