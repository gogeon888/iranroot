package com.rootmyvivo.root

import android.content.Context
import android.util.Log
import com.rootmyvivo.shell.AdbWire
import com.rootmyvivo.shell.Transport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

/**
 * 内置流程：GhostLock 引擎 + 无痕一键root 载荷链 + 已验证的合并脚本
 * （依然一键root 整合版 · 内置链 v3）
 *
 * 与 RootMyVivo 自带 payload 通道并行：命中内置内核走本链，失败自动回落。
 *
 * 设计要点（均已对着真源码/真脚本核实）：
 *  · 引擎硬编码 HOME = /data/local/tmp/ghostlock-app（无需改它）
 *  · 引擎/载荷以 lib*.so 形式随 APK 安装到 /data/app/…/lib/arm64/（shell 可读可执行）
 *    → 部署只需 shell 一条 cp，不需要 ADB push
 *  · 合并脚本由引擎自己生成（写入 .ghostlock_root.sh，模板在引擎内部）
 *    assets/glk/combined_root.sh 只是同内容的参考副本，运行时不依赖它
 *  · 看门狗由本 App 承担：轮询到 .ghostlock_root.sh 出现即执行（引擎卡死在 W2 也不影响）
 *  · 成功判定只认脚本自己打印的 verify 段（root 通道回显；shell 读不了 /proc/modules）
 */
object GlkChain {

    private const val TAG = "GlkChain"
    const val HOME = "/data/local/tmp/ghostlock-app"

    /** 内置链覆盖的内核（可继续增补） */
    private val BUILT_IN_KERNELS = listOf(
        "5.15.149-android13-8-gf81de23b360f-dirty",
    )

    /** jniLibs 载体文件名 → 设备上的真实名字（全部是 ELF，AGP 不会动） */
    private val CARRIERS = listOf(
        "libglk_engine.so" to "libgl_real.so",
        "libwk_a0.so"      to "a0",
        "libwk_b0.so"      to "b0",
        "libwk_b1.so"      to "b1",
        "libwk_c1.so"      to "c1",
        "libwk_c2.so"      to "c2",
        "libwk_d0.so"      to "d0",
    )

    private fun kernelLine(): String = try {
        val p = ProcessBuilder("/system/bin/sh", "-c", "uname -r").redirectErrorStream(true).start()
        val s = p.inputStream.bufferedReader().readText().trim()
        p.waitFor(); s
    } catch (_: Exception) { "" }

    fun isBuiltIn(ctx: Context): Boolean {
        val k = kernelLine()
        val hit = BUILT_IN_KERNELS.any { k == it || k.startsWith(it) }
        Log.i(TAG, "isBuiltIn: kernel=$k hit=$hit")
        return hit
    }

    /** shell 通道三级回退：ADB 已固定 → 无线调试直连 → null */
    private suspend fun shell(ctx: Context, cmd: String, timeoutSec: Int = 120): Pair<Int, String>? {
        val viaExec = try { Transport.exec(ctx, cmd, timeoutSec) } catch (_: Exception) { -1 to "" }
        if (viaExec.first == 0) return viaExec
        return try {
            AdbWire.shell(ctx, cmd, timeoutMs = timeoutSec * 1000L, allowDialog = true)
        } catch (e: Exception) {
            Log.w(TAG, "shell 不可用: ${e.message}"); null
        }
    }

    private fun deployCmd(pkg: String): String = buildString {
        append("set -e; L=\$(ls -d /data/app/*/").append(pkg).append("-*/lib/arm64 2>/dev/null | head -1); ")
        append("[ -n \"\$L\" ] || { echo NO_LIBDIR; exit 9; }; ")
        append("mkdir -p ").append(HOME).append("; chmod 0777 ").append(HOME).append("; ")
        for ((from, to) in CARRIERS) {
            append("cp -f \"\$L/").append(from).append("\" ").append(HOME).append('/').append(to).append("; ")
        }
        append("chmod 0755 ").append(HOME).append("/libgl_real.so ")
        append(HOME).append("/a0 ").append(HOME).append("/b0 ").append(HOME).append("/b1 ")
        append(HOME).append("/c1 ").append(HOME).append("/c2 ").append(HOME).append("/d0; echo DEPLOY_OK")
    }

    /**
     * 跑完整内置流程。返回 true = verify 通过（uid=0 + Permissive + kernelsu=1）。
     */
    suspend fun run(ctx: Context, log: suspend (String) -> Unit): Boolean = withContext(Dispatchers.IO) {
        // 1) 部署 + 落脚本
        val dep = shell(ctx, deployCmd(ctx.packageName), 180)
        if (dep == null) {
            log("[!] 拿不到 shell 通道：请开启开发者选项里的「无线调试」并允许授权；或先用 Shizuku 方式成功跑一次以固定 ADB 5555")
            return@withContext false
        }
        dep.second.lineSequence().filter { it.isNotBlank() }.forEach { log(it) }
        if (!dep.second.contains("DEPLOY_OK")) { log("[!] 部署失败（返回码 ${dep.first}）"); return@withContext false }

        // 2) 起引擎（后台）；看门狗由本 App 承担
        val started = shell(ctx, "cd $HOME && rm -f .glk_done .ghostlock_root.sh .glk_tail.log .glk_script_run; " +
                "nohup ./libgl_real.so > $HOME/.glk_engine.log 2>&1 & echo ENGINE_STARTED", 60)
        if (started == null || !started.second.contains("ENGINE_STARTED")) {
            log("[!] 引擎启动失败"); return@withContext false
        }
        log("[*] 引擎已启动；等待脚本出现即接管")

        // 3) 轮询：脚本一出现就执行一次（等价 shim 的作用），随后推进日志并判成功
        var scriptRun = false
        var printed = 0
        var ok = false
        for (i in 1..220) {
            delay(2500)
            if (!scriptRun) {
                val chk = shell(ctx, "[ -s $HOME/.ghostlock_root.sh ] && echo YES || echo NO", 30)
                if (chk?.second?.contains("YES") == true) {
                    shell(ctx, "cd $HOME && nohup /system/bin/sh .ghostlock_root.sh >/dev/null 2>&1 & echo RUN", 30)
                    scriptRun = true
                    log("[*] 脚本已生成，开始执行越狱链")
                }
            }
            val tail = shell(ctx, "L=\$(ls -t $HOME/ghostlock-ksu-*.log 2>/dev/null | head -1); " +
                    "echo \"LOG=\$L\"; tail -c 20000 \"\$L\" 2>/dev/null; echo ---; " +
                    "tail -c 4000 $HOME/.glk_tail.log 2>/dev/null", 30) ?: continue
            val body = tail.second
            val lines = body.lineSequence().filter { it.isNotBlank() }.toList()
            if (lines.size > printed) { lines.drop(printed).forEach { log(it) }; printed = lines.size }
            val afterVerify = body.substringAfter("===== verify =====", "")
            val verified = afterVerify.contains("uid=0(root)") && afterVerify.contains("Permissive") &&
                           Regex("(?m)^1\\s*$").containsMatchIn(afterVerify)
            if (verified) { ok = true; log("[+] verify 通过：uid=0 ✓ Permissive ✓ kernelsu=1 ✓"); break }
            if (body.contains("失败:")) { log("[!] 脚本报告失败（可再点一次，漏洞利用有概率性）"); break }
            if (!scriptRun && i == 30) log("[!] 引擎未生成脚本（说明这次漏洞利用没打穿），可再点一次")
            if (i % 12 == 0) log("[*] 进行中…（${i * 5 / 2}s）")
        }

        // 4) 固定 ADB 5555（保证下次重启能全自动恢复）
        if (ok) {
            try { Transport.persistAfterRoot(ctx) } catch (e: Exception) { Log.w(TAG, "persist: ${e.message}") }
            log("[*] 已固定 ADB over TCP 5555（下次重启可自动恢复 root）")
        }
        ok
    }

    /** root 还活着时只补拉起 KernelSU（不重跑漏洞） */
    suspend fun onlyLaunchKsu(ctx: Context, log: suspend (String) -> Unit) = withContext(Dispatchers.IO) {
        log("[*] 已有 root，仅拉起 KernelSU")
        shell(ctx, "( for d in 2 3 5; do sleep \$d; am start -n me.weishu.kernelsu/.ui.MainActivity -f 0x10200000 >/dev/null 2>&1; done ) & echo OK", 30)
        Unit
    }
}
