package com.rootmyvivo.vm

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rootmyvivo.R
import com.rootmyvivo.data.AppUpdate
import com.rootmyvivo.data.AppUpdater
import com.rootmyvivo.data.Catalog
import com.rootmyvivo.data.DeviceInfo
import com.rootmyvivo.data.Prefs
import com.rootmyvivo.vm.LogKind
import com.rootmyvivo.data.Settings
import com.rootmyvivo.root.ExploitEngine
import com.rootmyvivo.root.FlowEvent
import com.rootmyvivo.root.LogLevel
import com.rootmyvivo.root.KsuVariant
import com.rootmyvivo.root.RootTraces
import com.rootmyvivo.shell.Transport
import com.rootmyvivo.shell.TransportState
import com.rootmyvivo.ui.flow.FlowUiReducer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    private val prefs = Prefs(app)
    private val catalog = Catalog()
    /** Общий редьюсер потока рута: боевой процесс и демо из «Другое» — один UI-код. */
    private val ui by lazy { FlowUiReducer(app) }
    private var engine: ExploitEngine? = null
    private var updateCheckJob: kotlinx.coroutines.Job? = null

    init {
        Transport.prefs = prefs
        Catalog.initCache(app.filesDir)
        // Кеш обновлений: скачанные APK скапливаются — чистим при старте
        AppUpdater.sweepUpdateCache(app)
        _state.value = _state.value.copy(
            settings = prefs.settings(),
            selectedKsu = KsuVariant.byId(prefs.selectedKsu),
            needsSoftReboot = prefs.softRebootPendingActual(),
            logHistory = loadLogHistory(),
            tgBannerVisible = !prefs.tgPromoDismissed,
        )
        // ADB-бейдж: порт закреплён и канал жив
        detectDevice()
        refreshTransport()
        // Автопоиск обновлений при каждом запуске приложения
        if (_state.value.settings.autoUpdateCheck) checkForUpdate()
    }

    // ─────────── Устройство и каталог ───────────

    fun detectDevice() {
        viewModelScope.launch {
            _state.value = _state.value.copy(rootState = RootState.CHECKING)

            val device = withContext(Dispatchers.IO) { DeviceInfo.detect() }
            val rooted = withContext(Dispatchers.IO) {
                val ctx = getApplication<Application>()
                // Локально: демон эксплойта (до загрузки KSU). После KSU рут
                // доступен только shell-домену (allow_shell) — проверяем ещё и
                // через транспорт, иначе после софт-ребута живой рут выглядел бы пропавшим
                Transport.rootActiveQuick(ctx) ||
                    runCatching { Transport.su(ctx, "true", timeoutSec = 15).first == 0 }.getOrDefault(false)
            }
            if (rooted) prefs.firstRootDone = true

            // Устройство показываем сразу — каталог не должен блокировать UI
            _state.value = _state.value.copy(
                device = device,
                rootState = if (rooted) RootState.ROOTED else RootState.NOT_ROOTED,
            )

            // Каталог в фоне
            if (_state.value.settings.catalogUrl.contains("/devices.json")) {
                catalog.url = _state.value.settings.catalogUrl
            }
            val result = catalog.fetch()
            val cat = result.getOrNull()
            val catDev = cat?.let { catalog.findDevice(it, device) }
            _state.value = _state.value.copy(
                payload = cat?.let { catalog.findPayload(it, device) },
                catalogState = if (cat != null) CatalogState.READY else CatalogState.ERROR,
                catalogData = cat,
                deviceInCatalog = catDev != null,
                catalogMarketName = catDev?.marketName?.takeIf { it.isNotEmpty() },
                catalogDeviceCode = catDev?.code?.takeIf { it.isNotEmpty() },
            )
        }
    }

    // ─────────── ADB-канал (бейдж закрепления) ───────────

    fun refreshTransport() {
        viewModelScope.launch {
            val t = withContext(Dispatchers.IO) { Transport.detectBlocking(getApplication()) }
            _state.value = _state.value.copy(transport = t)
        }
    }

    // ─────────── Процесс рута ───────────

    fun startRoot() {
        val device = _state.value.device ?: return
        if (_state.value.flowRunning) return
        val ctx = getApplication<Application>()
        engine = ExploitEngine(ctx, device, catalog)
        runStartedAt = System.currentTimeMillis()
        _state.value = _state.value.copy(
            flowRunning = true,
            log = emptyList(),
            exploitLive = ExploitLiveState(),
            flowResult = null,
            downloadProgress = null,
            softRebootPrompt = false,
            // rootState не трогаем: без «проверки состояния» между кнопкой и экраном взлома
        )
        // Foreground-сервис: процесс рута продолжается и в фоне
        com.rootmyvivo.ExploitService.start(ctx, ctx.getString(R.string.notif_root_running))

        viewModelScope.launch {
            val variant = _state.value.selectedKsu
            val custom = _state.value.customPayload
            // Эксплойт уже работает (приложение вылетело/перезапущено)?
            // Подхватываем его живой лог вместо запуска нового параллельного процесса
            val alreadyRunning = withContext(Dispatchers.IO) {
                runCatching { engine!!.detectRunning() }.getOrDefault(false)
            }
            val ok = try {
                when {
                    alreadyRunning -> engine!!.runAttached(variant) { e -> applyFlowEvent(e) }
                    // Кастомный пейлоад: минимальный путь без каталога и загрузок,
                    // деплоит выбранный пользователем файл как есть
                    custom != null -> engine!!.runCustomPreload(custom.file, variant) { e -> applyFlowEvent(e) }
                    else -> engine!!.run(variant) { e -> applyFlowEvent(e) }
                }
            } catch (e: Exception) {
                // Сетевая/иная авария внутри движка: превращаем в явный сбой,
                // иначе кнопка «в процессе» висела бы вечно
                Log.e(TAG, "root flow crashed", e)
                applyFlowEvent(FlowEvent.Failure(FlowEvent.Reason.OTHER))
                false
            }
            _state.value = _state.value.copy(flowRunning = false)
            com.rootmyvivo.ExploitService.stop(ctx)
            if (ok) {
                prefs.firstRootDone = true
                refreshTransport()
            }
            // Автопоиск обновлений после каждого запуска — если включён
            if (_state.value.settings.autoUpdateCheck) checkForUpdate()
        }
    }

    fun stopRoot() {
        engine?.stop()
        _state.value = _state.value.copy(flowRunning = false)
        com.rootmyvivo.ExploitService.stop(getApplication())
        // Остановка — тоже завершение запуска: пишем лог в историю, иначе
        // прерванный запуск исчезал бесследно (событие Failure не приходит)
        saveLogHistory(success = false, failReason = "STOPPED_BY_USER")
        // «Принудительно» — не только бросить наблюдение во флоу, но и
        // прибить сам демон на устройстве: процесс с LD_PRELOAD=rmv/preload.so
        // (cmdline у него /system/bin/true, поэтому ищем через maps)
        val ctx = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                Transport.exec(
                    ctx,
                    "for d in \$(grep -l rmv/preload.so /proc/[0-9]*/maps 2>/dev/null | cut -d/ -f3); do kill -9 \$d 2>/dev/null; done",
                    timeoutSec = 20,
                )
            }
        }
    }

    // ─────────── Кастомный пейлоад ───────────

    /**
     * Пользователь выбрал файл в SAF-пикере: копируем содержимое в
     * filesDir/payloads/preload.so (движок деплоит файл с этим именем)
     * и показываем в главной карточке. Никаких загрузок — запуск идёт
     * строго из этого файла. Файл обязан быть ELF64-библиотекой aarch64:
     * заголовок проверяем до приёма, картинка/текст в пикере не проходят.
     */
    fun onCustomPayloadPicked(uri: Uri) {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val workDir = java.io.File(ctx.filesDir, "payloads").apply { mkdirs() }
                    val dest = java.io.File(workDir, "preload.so")
                    ctx.contentResolver.openInputStream(uri)?.use { input ->
                        dest.outputStream().use { output -> input.copyTo(output) }
                    } ?: throw IllegalStateException("resolver returned no stream")
                    if (!isElf64Aarch64(dest)) {
                        dest.delete()
                        throw NotELF()
                    }
                    val name = queryDisplayName(uri) ?: "payload.so"
                    name to dest.length()
                }
            }
            ok.onSuccess { (name, size) ->
                // Загруженные ранее файлы каталога больше не актуальны
                _state.value = _state.value.copy(
                    customPayload = CustomPayload(name, size, java.io.File(ctx.filesDir, "payloads/preload.so")),
                    flowResult = null,
                )
                addLog(ctx.getString(R.string.log_custom_selected, name))
            }.onFailure { e ->
                Log.w(TAG, "custom payload copy failed: ${e.message}")
                val res = if (e is NotELF) R.string.log_custom_not_so else R.string.log_custom_copy_failed
                _state.value = _state.value.copy(toastRes = res)
                addLog(ctx.getString(res))
            }
        }
    }

    /** UI показал тост — событие больше не нужно. */
    fun consumeToast() {
        _state.value = _state.value.copy(toastRes = null)
    }

    private class NotELF : Exception("not an ELF64 aarch64 shared object")

    /** ELF64 little-endian с e_machine == EM_AARCH64 (0xB7). */
    private fun isElf64Aarch64(f: java.io.File): Boolean = try {
        val hdr = ByteArray(20)
        java.io.FileInputStream(f).use { input ->
            var read = 0
            while (read < 20) {
                val n = input.read(hdr, read, 20 - read)
                if (n < 0) break
                read += n
            }
            if (read < 20) return false
        }
        hdr[0] == 0x7F.toByte() && hdr[1] == 'E'.code.toByte() &&
            hdr[2] == 'L'.code.toByte() && hdr[3] == 'F'.code.toByte() &&
            hdr[4] == 2.toByte() && hdr[5] == 1.toByte() &&
            (hdr[18].toInt() and 0xFF) or ((hdr[19].toInt() and 0xFF) shl 8) == 0xB7
    } catch (_: Exception) {
        false
    }

    /**
     * Настройки «Другое» → «Очистить следы root»: снести временные su-файлы.
     * Работает только через RootTraces с его гейтом — если ksud не отвечает,
     * удалять нечего и нечем (root ещё на клиенте демона).
     */
    fun cleanRootTraces() {
        if (_state.value.flowRunning) return
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val outcome = withContext(Dispatchers.IO) { RootTraces.clean(ctx) }
            addLog(
                ctx.getString(
                    when (outcome) {
                        RootTraces.Outcome.CLEANED -> R.string.log_traces_cleaned
                        RootTraces.Outcome.NO_KSUD -> R.string.log_traces_no_ksud
                        RootTraces.Outcome.FAILED -> R.string.log_traces_failed
                    },
                ),
            )
            detectDevice()
        }
    }

    /** Отвязать кастомный пейлоад — вернуть обычный путь каталога. */
    fun clearCustomPayload() {
        _state.value = _state.value.copy(customPayload = null)
    }

    private fun queryDisplayName(uri: Uri): String? = try {
        val ctx = getApplication<Application>()
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
        }
    } catch (_: Exception) {
        null
    }

    // ─────────── Обновление приложения ───────────

    /**
     * Проверить обновления в фоне (GitHub releases; бета-канал — beta/pre-release).
     * Результат — диалог + компактная плашка на главной. Повторные вызовы
     * схлопываются. manual=true — по кнопке: без обновлений показывает тост.
     */
    fun checkForUpdate(manual: Boolean = false) {
        if (updateCheckJob?.isActive == true) return
        updateCheckJob = viewModelScope.launch {
            val update = withContext(Dispatchers.IO) {
                AppUpdater.check(getApplication(), _state.value.settings.betaChannel)
            }
            // не перетираем активное скачивание предыдущей проверки
            if (_state.value.updateDownload == null) {
                _state.value = _state.value.copy(
                    appUpdate = update,
                    updateDialogOpen = update != null,
                )
                if (manual && update == null) {
                    val ctx = getApplication<Application>()
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        android.widget.Toast.makeText(
                            ctx,
                            ctx.getString(R.string.update_none_found),
                            android.widget.Toast.LENGTH_SHORT,
                        ).show()
                    }
                }
            }
        }
    }

    /**
     * Универсальное действие кнопки обновления: до скачивания — скачать и
     * установить, после — переоткрыть системный установщик.
     */
    fun updateAction() {
        if (_state.value.updateDownload?.done == true) {
            retryInstallDownloaded()
        } else {
            downloadAndInstallUpdate()
        }
    }

    /** Закрыть диалог — компактная плашка остаётся на главной */
    fun dismissUpdateDialog() {
        _state.value = _state.value.copy(updateDialogOpen = false)
    }

    // ─────────── Плашка Telegram (первый запуск) ───────────

    /** «Пропустить» или переход по ссылке — плашка больше не вернётся. */
    fun dismissTgBanner() {
        prefs.tgPromoDismissed = true
        _state.value = _state.value.copy(tgBannerVisible = false)
    }

    /** «Перейти» — открыть Telegram-канал и закрыть плашку. */
    fun openTelegramChannel() {
        val ctx = getApplication<Application>()
        try {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(TELEGRAM_CHANNEL_URL))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        } catch (e: Exception) {
            Log.w(TAG, "open telegram failed: ${e.message}")
            android.widget.Toast.makeText(ctx, R.string.link_open_failed, android.widget.Toast.LENGTH_SHORT).show()
        }
        dismissTgBanner()
    }

    fun dismissUpdate() {
        _state.value = _state.value.copy(appUpdate = null)
    }

    /** Скачать APK обновления с живым прогрессом и открыть установщик. */
    fun downloadAndInstallUpdate() {
        val update = _state.value.appUpdate ?: return
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            _state.value = _state.value.copy(
                updateDownload = UpdateDownloadState(update.versionName, 0, update.apkSize),
            )
            try {
                val apk = AppUpdater.download(update, ctx) { read, total ->
                    _state.value = _state.value.copy(
                        updateDownload = UpdateDownloadState(update.versionName, read, total),
                    )
                }
                _state.value = _state.value.copy(
                    updateDownload = UpdateDownloadState(update.versionName, apk.length(), apk.length()),
                    updateInstalling = true,
                )
                val started = AppUpdater.install(apk, ctx)
                if (!started) {
                    _state.value = _state.value.copy(updateInstalling = false)
                } else {
                    // установщик открыт — закрываем диалог, карточка остаётся
                    // с кнопкой «Установить» на случай возврата назад
                    _state.value = _state.value.copy(updateDialogOpen = false)
                }
            } catch (e: Exception) {
                Log.w(TAG, "update download failed: ${e.message}")
                _state.value = _state.value.copy(
                    updateDownload = null,
                    appUpdate = update, // плашку возвращаем — можно повторить
                )
            }
        }
    }

    /** Повторно открыть установщик уже скачанного APK (после возврата). */
    fun retryInstallDownloaded() {
        val dl = _state.value.updateDownload ?: return
        if (!dl.done) return
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            // ищем скачанный файл по маске — имя содержит versionName
            val dir = ctx.externalCacheDir ?: ctx.cacheDir
            val f = dir.listFiles()
                ?.filter { it.name.startsWith("rmv-update-") && it.name.endsWith(".apk") }
                ?.maxByOrNull { it.lastModified() }
            if (f != null && f.exists()) AppUpdater.install(f, ctx)
        }
    }

    /** Soft reboot — только по подтверждению пользователя. */
    fun performSoftReboot() {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            addLog(ctx.getString(R.string.log_softreboot_perform))
            // SIGKILL, как в оригинальном эксплойте: мгновенная смерть system_server —
            // зигота сразу перезапускает интерфейс. SIGTERM виснет на минуты
            var (code, out) = withContext(Dispatchers.IO) {
                Transport.su(ctx, "kill -9 \$(pidof system_server)")
            }
            if (code != 0) {
                Log.w(TAG, "soft reboot via kill failed: ${out.take(100)}")
                code = withContext(Dispatchers.IO) { Transport.su(ctx, "stop").first }
                if (code == 0) code = withContext(Dispatchers.IO) { Transport.su(ctx, "start").first }
            }
            if (code != 0) {
                addLog(ctx.getString(R.string.log_softreboot_fail))
                // Плашку оставляем: можно попробовать ещё раз
                _state.value = _state.value.copy(softRebootPrompt = false)
            } else {
                // Интерфейс перезапускается — ядро чистое, статус сбрасываем насовсем
                prefs.softRebootPending = false
                _state.value = _state.value.copy(
                    softRebootPrompt = false,
                    needsSoftReboot = false,
                )
            }
        }
    }

    fun dismissSoftReboot() {
        _state.value = _state.value.copy(softRebootPrompt = false)
    }

    /** Открыть лог конкретного запуска из истории. */
    fun openLogRun(info: LogRunInfo) {
        val entries = try {
            info.file.readLines().drop(1).mapIndexedNotNull { i, line ->
                val idx = line.indexOf('\t')
                if (idx <= 0) {
                    null
                } else {
                    val st = runCatching { LogLevel.valueOf(line.substring(0, idx)) }.getOrDefault(LogLevel.INFO)
                    val text = line.substring(idx + 1)
                    // Шаг эксплойта в сохранённом логе: детектим по тексту
                    // (все локали) — вьюер рендерит его бутербродом
                    val kind = if (text.startsWith("Запуск эксплойта") ||
                        text.startsWith("Running exploit") ||
                        text.startsWith("正在运行漏洞利用")
                    ) LogKind.EXPLOIT else LogKind.NORMAL
                    LogEntry(i.toLong(), text, st, kind)
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
        val exploit = try {
            info.exploitFile?.takeIf { it.exists() }
                ?.readLines()
                ?.filter { it.isNotBlank() }
                ?.takeLast(300)
                ?: emptyList()
        } catch (_: Exception) {
            emptyList()
        }
        _state.value = _state.value.copy(
            lastLog = entries,
            lastExploitLog = exploit,
        )
    }

    /** История запусков на диск: до 5 последних, с метаданными. Переживает ребут. */
    private fun saveLogHistory(success: Boolean, failReason: String?) {
        try {
            val ctx = getApplication<Application>()
            val dir = java.io.File(ctx.filesDir, "logs").apply { mkdirs() }
            val start = runStartedAt
            val dur = (System.currentTimeMillis() - start) / 1000
            val body = _state.value.log.joinToString("\n") { entry ->
                entry.status.name + "\t" + entry.text.replace('\n', ' ')
            }
            // Метастрока + лог; имя файла = время старта запуска
            val f = java.io.File(dir, "$start.log")
            f.writeText(
                "META\t$start\t$dur\t${if (success) "ok" else "fail"}\t" +
                    "${failReason ?: ""}\t${_state.value.selectedKsu.displayName}\t${_state.value.log.size}\n" +
                    body,
            )
            // Живой лог эксплойта (live.log: попытки, CFI-этапы, phys step,
            // cred) — отдельным файлом, рядом; нужен для разбора сбоев
            val live = _state.value.exploitLive.lines
            if (live.isNotEmpty()) {
                java.io.File(dir, "$start.exploit.log").writeText(
                    live.joinToString("\n") { it.text },
                )
            }
            // старее 5 запусков — вычищаем (и live-логи тоже)
            dir.listFiles { x -> x.name.endsWith(".log") }
                ?.sortedByDescending { it.name }
                ?.groupBy { it.name.substringBefore('.') }
                ?.let { groups ->
                    groups.entries.sortedByDescending { it.key.toLongOrNull() ?: 0L }
                        .drop(5)
                        .forEach { (_, files) -> files.forEach { it.delete() } }
                }
            _state.value = _state.value.copy(logHistory = loadLogHistory())
        } catch (_: Exception) {
        }
    }

    private fun loadLogHistory(): List<LogRunInfo> = try {
        val dir = java.io.File(getApplication<Application>().filesDir, "logs")
        dir.listFiles { x -> x.name.endsWith(".log") && !x.name.endsWith(".exploit.log") }
            ?.sortedByDescending { it.name }
            ?.mapNotNull { f ->
                val meta = f.useLines { it.firstOrNull() } ?: return@mapNotNull null
                val p = meta.split('\t')
                if (p.size < 7 || p[0] != "META") return@mapNotNull null
                val exploit = java.io.File(f.parentFile, f.nameWithoutExtension + ".exploit.log")
                LogRunInfo(
                    startedAt = p[1].toLongOrNull() ?: return@mapNotNull null,
                    durationSec = p[2].toLongOrNull() ?: 0,
                    // "running" — запуск был прерван смертью процесса; итога
                    // нет, показываем как fail (лог-то сохранился — его можно
                    // скинуть и разобрать)
                    success = p[3] == "ok",
                    failReason = when (p[3]) {
                        "ok" -> p[4].ifEmpty { null }
                        "running" -> "INTERRUPTED"
                        else -> p[4].ifEmpty { null }
                    },
                    variant = p[5],
                    lines = p[6].toIntOrNull() ?: 0,
                    file = f,
                    exploitFile = exploit.takeIf { it.exists() },
                )
            } ?: emptyList()
    } catch (_: Exception) {
        emptyList()
    }

    /** Время старта текущего/последнего запуска — для метаданных истории. */
    private var runStartedAt = System.currentTimeMillis()

    /** Момент последнего применённого события — троттлинг 0.1с: пачки
     *  лог-строк вылетают по одной, не залпом (красиво в терминале) */
    private var lastFlowEventAt = 0L

    private fun applyFlowEvent(event: FlowEvent) {
        // Троттлинг — только для «текстовых» событий (Log/Progress/Complete);
        // Step/Download/Success/Failure применяются мгновенно
        val textual = event is FlowEvent.Log || event is FlowEvent.Progress ||
            event is FlowEvent.Complete
        if (textual) {
            val now = System.currentTimeMillis()
            val wait = 100L - (now - lastFlowEventAt)
            if (wait > 0) {
                try {
                    Thread.sleep(wait)
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                }
            }
            lastFlowEventAt = System.currentTimeMillis()
        }
        var s = ui.apply(_state.value, event)
        when (event) {
            is FlowEvent.Step ->
                com.rootmyvivo.ExploitService.update(getApplication(), ui.phaseText(event.phase))

            is FlowEvent.ExploitLive ->
                com.rootmyvivo.ExploitService.update(getApplication(), ui.exploitText(event.attempt, event.max))

            is FlowEvent.Success ->
                s = finishRun(s, success = true, failReason = null, suggestReboot = event.softRebootRecommended)

            FlowEvent.NeedsSoftReboot ->
                s = finishRun(s, success = true, failReason = null, suggestReboot = true)

            is FlowEvent.Failure ->
                s = finishRun(s, success = false, failReason = event.reason.name, suggestReboot = false)

            else -> {}
        }
        _state.value = s
        // Инкрементальное сохранение: шаги/живой лог пишутся на диск по мере
        // появления, а не только в конце запуска. Если приложение умрёт
        // (краш, убийство системой, перезапуск) — лог запуска и live-лог
        // остаются в истории, пользователь может их скинуть
        if (event is FlowEvent.Step || event is FlowEvent.ExploitLive ||
            event is FlowEvent.Complete || event is FlowEvent.Progress
        ) {
            saveLogHistoryPartial()
        }
    }

    /**
     * Инкрементальная запись истории: тот же файл запуска, но без смены
     * итога (итог пишется только finishRun). Дешёвая перезапись маленького
     * файла на каждое событие — вместо потерянных логов при смерти процесса.
     */
    private fun saveLogHistoryPartial() {
        try {
            val ctx = getApplication<Application>()
            val dir = java.io.File(ctx.filesDir, "logs").apply { mkdirs() }
            val start = runStartedAt
            val st = _state.value
            val body = st.log.joinToString("\n") { entry ->
                entry.status.name + "\t" + entry.text.replace('\n', ' ')
            }
            // Итог неизвестен (запуск ещё идёт) — пишем "running"; finishRun
            // перезапишет с финальным ok/fail
            java.io.File(dir, "$start.log").writeText(
                "META\t$start\t0\trunning\t\t${st.selectedKsu.displayName}\t${st.log.size}\n" + body,
            )
            val live = st.exploitLive.lines
            if (live.isNotEmpty()) {
                java.io.File(dir, "$start.exploit.log").writeText(
                    live.joinToString("\n") { it.text },
                )
            }
        } catch (_: Exception) {
        }
    }

    /** Хвост запуска: «Готово» при успехе, история на диск, флаг софт-ребута. */
    private fun finishRun(
        s: UiState,
        success: Boolean,
        failReason: String?,
        suggestReboot: Boolean,
    ): UiState {
        var st = s
        if (success) {
            st = st.copy(
                log = st.log + LogEntry(
                    ui.nextLogId(),
                    getApplication<Application>().getString(R.string.log_done),
                    LogLevel.OK,
                ),
            )
            // Софт-ребут рекомендуем только когда KSU реально загрузился
            if (suggestReboot) {
                prefs.softRebootPending = true
                prefs.rootBootId = prefs.currentBootId()
                st = st.copy(needsSoftReboot = true)
            }
        }
        // История пишется из состояния — публикуем строку «Готово» до записи
        _state.value = st
        saveLogHistory(success, failReason)
        return st.copy(lastLog = st.log)
    }

    // ─────────── Настройки ───────────

    fun selectKsu(variant: KsuVariant) {
        prefs.selectedKsu = variant.id
        _state.value = _state.value.copy(selectedKsu = variant)
    }

    fun updateSettings(transform: (Settings) -> Settings) {
        val new = transform(_state.value.settings)
        prefs.saveSettings(new)
        // Каталог v5 (devices.json): кастомный URL применяется, только если
        // это он — файлы формата v4 дают пустой каталог
        if (new.catalogUrl.contains("/devices.json")) catalog.url = new.catalogUrl
        _state.value = _state.value.copy(settings = new)
    }

    fun setCatalogUrl(url: String) {
        updateSettings { it.copy(catalogUrl = url.trim().ifEmpty { Catalog.DEFAULT_URL }) }
        detectDevice()
    }

    // ─────────── Диагностика ───────────

    fun adbSelfTest() {
        viewModelScope.launch {
            addLog(getApplication<Application>().getString(R.string.log_adb_test))
            withContext(Dispatchers.IO) { Transport.adbSelfTest(getApplication()) }
                .forEach { addLog(it) }
            refreshTransport()
        }
    }

    private fun addLog(text: String) {
        _state.value = _state.value.copy(
            log = _state.value.log + LogEntry(ui.nextLogId(), text, LogLevel.PLAIN),
        )
    }

    companion object {
        private const val TAG = "NeoVM"
        private const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
        private const val SHIZUKU_DOWNLOAD_URL = "https://github.com/RikkaApps/Shizuku/releases"
        private const val TELEGRAM_CHANNEL_URL = "https://t.me/zenyxx_projects"
    }
}
