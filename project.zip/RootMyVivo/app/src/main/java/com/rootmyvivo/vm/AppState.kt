package com.rootmyvivo.vm

import com.rootmyvivo.data.DeviceInfo
import com.rootmyvivo.data.PayloadCatalog
import com.rootmyvivo.data.PayloadMatch
import com.rootmyvivo.data.Settings
import com.rootmyvivo.root.KsuVariant
import com.rootmyvivo.root.LogLevel
import com.rootmyvivo.root.Phase
import com.rootmyvivo.shell.TransportState

enum class RootState { UNKNOWN, CHECKING, NOT_ROOTED, ROOTED, FAILED }
enum class CatalogState { LOADING, READY, ERROR }

data class LogEntry(val id: Long, val text: String, val status: LogLevel, val kind: LogKind = LogKind.NORMAL)

/** Сохранённый запуск для истории логов. */
data class LogRunInfo(
    val startedAt: Long,
    val durationSec: Long,
    val success: Boolean,
    val failReason: String?,
    val variant: String,
    val lines: Int,
    val file: java.io.File,
    /** Живой лог эксплойта (live.log), если был сохранён */
    val exploitFile: java.io.File? = null,
)

/** Тип строки лога: обычная или шаг эксплойта (раскрываемый аккордеон). */
enum class LogKind { NORMAL, EXPLOIT }

/** Строка живого лога с устойчивым id — для анимации появления. */
data class LiveLogLine(val id: Long, val text: String)

/** Живой лог эксплойта: накопленный вывод бинаря для аккордеона. */
data class ExploitLiveState(
    val attempt: Int? = null,
    val max: Int? = null,
    val lines: List<LiveLogLine> = emptyList(),
)

sealed interface FlowResult {
    data object Success : FlowResult
    data class Failure(val reason: com.rootmyvivo.root.FlowEvent.Reason) : FlowResult
}

/** Прогресс скачивания обновления приложения. */
data class UpdateDownloadState(
    val versionName: String,
    val read: Long,
    val total: Long,
) {
    val fraction: Float? get() = if (total > 0) read.toFloat() / total else null
    val done: Boolean get() = total > 0 && read >= total
}

/** Кастомный пейлоад, выбранный пользователем через файловый менеджер. */
data class CustomPayload(
    val displayName: String,
    val size: Long,
    /** Локальный файл в filesDir/payloads, готовый к деплою. */
    val file: java.io.File,
)

data class UiState(
    // устройство и каталог
    val device: DeviceInfo? = null,
    /** Найденный живой пейлоад: тело + готовая сборка ядра из каталога v5. */
    val payload: PayloadMatch? = null,
    val catalogState: CatalogState = CatalogState.LOADING,
    /** Последний загруженный каталог: экран поддерживаемых устройств
     *  переиспользует его вместо второй сетевой загрузки. */
    val catalogData: PayloadCatalog? = null,
    /** Тело пользователя есть в каталоге (независимо от ядра) — для
     *  «Устройство не поддерживается» vs «Ядро … не поддерживается». */
    val deviceInCatalog: Boolean = false,
    /** Маркет-нейм из каталога («vivo X200 Pro») для строки «Модель». */
    val catalogMarketName: String? = null,
    /** Код тела из каталога («PD2405»/V-код) — вместо Build.DEVICE в скобках. */
    val catalogDeviceCode: String? = null,
    /** Одноразовый тост (string resource id): UI показывает и гасит consumeToast */
    val toastRes: Int? = null,
    // кастомный пейлоад (выбран через файловый менеджер): деплоится именно
    // этот файл — каталог и GitHub при таком запуске не используются
    val customPayload: CustomPayload? = null,
    // найденное обновление приложения (плашка на главной)
    val appUpdate: com.rootmyvivo.data.AppUpdate? = null,
    /** Диалог обновления открыт (первый показ после нахождения) */
    val updateDialogOpen: Boolean = false,
    /** Скачивание обновления: файл + прогресс [0..1] или null при неизвестном размере */
    val updateDownload: UpdateDownloadState? = null,
    /** Плашка-обновление показана диалогом или компактно */
    val updateInstalling: Boolean = false,
    /** Плашка первого запуска с просьбой подписаться на Telegram-канал */
    val tgBannerVisible: Boolean = false,
    // транспорт и root
    val transport: TransportState = TransportState.None,
    val rootState: RootState = RootState.UNKNOWN,
    // настройки
    val settings: Settings = Settings(),
    val selectedKsu: KsuVariant = KsuVariant.RESUKISU,
    // процесс рута
    val flowRunning: Boolean = false,
    val flowPhase: Phase? = null,
    val stepIndex: Int = 0,
    val stepTotal: Int = 6,
    /** Прогресс процесса в процентах: двигается лог-событиями по весам */
    val flowPercent: Int = 0,
    val downloadProgress: Float? = null,
    val log: List<LogEntry> = emptyList(),
    val exploitLive: ExploitLiveState = ExploitLiveState(),
    val flowResult: FlowResult? = null,
    val softRebootPrompt: Boolean = false,
    /** Root есть, но soft reboot ещё не выполнен — показать кнопку на главной */
    val needsSoftReboot: Boolean = false,
    /** Сохранённый последний лог для просмотра */
    val lastLog: List<LogEntry> = emptyList(),
    /** Live-лог эксплойта для просмотра из истории */
    val lastExploitLog: List<String> = emptyList(),
    /** История запусков (до 5 последних) */
    val logHistory: List<LogRunInfo> = emptyList(),
)
