﻿package com.rootmyvivo.ui.settings

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.CloudSync
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.SystemUpdate
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rootmyvivo.BuildConfig
import com.rootmyvivo.R
import com.rootmyvivo.data.Prefs
import com.rootmyvivo.ui.common.SettingsDivider
import com.rootmyvivo.ui.common.SettingsGroup
import com.rootmyvivo.ui.common.SettingsRow
import com.rootmyvivo.ui.common.TrailingValue
import com.rootmyvivo.vm.MainViewModel
import com.rootmyvivo.vm.UiState

private val REPO_APP = "https://github.com/zenyxx-xd/RootMyVivo"
private val REPO_PAYLOADS = "https://github.com/zenyxx-xd/RootMyVivo-Payloads"
private val REPO_EXPLOIT = "https://github.com/zenyxx-xd/RootMyVivo-Exploit"
private const val TELEGRAM_CHANNEL = "zenyxx_projects"

private fun openUrl(context: Context, url: String) {
    try {
        context.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse(url))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    } catch (_: Exception) {
        Toast.makeText(context, context.getString(R.string.link_open_failed), Toast.LENGTH_SHORT).show()
    }
}

/**
 * «О приложении»: шапка с иконкой и версией, обновления, репозитории,
 * дисклеймер. Семь тапов по версии — разблокировка меню разработчика.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(vm: MainViewModel, state: UiState, onClose: () -> Unit) {
    val context = LocalContext.current

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.about_title)) },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, stringResource(R.string.action_back))
                    }
                },
            )
        },
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Spacer(Modifier.height(4.dp))

            // ── Шапка: иконка, название, версия, автор ──
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.extraLarge,
                color = MaterialTheme.colorScheme.primaryContainer,
            ) {
                Column(
                    Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    // Плотный вектор (ic_app_logo): сам замок без лаунчерных
                    // полей и подложки — акцентом служит фон самой карточки
                    Image(
                        painter = painterResource(R.drawable.ic_app_logo),
                        contentDescription = null,
                        modifier = Modifier.size(62.dp),
                    )
                    Spacer(Modifier.height(7.dp))
                    Text(
                        stringResource(R.string.app_name),
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        "v${BuildConfig.VERSION_NAME}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 2.dp),
                    )
                }
            }

            // ── Обновления ──
            SettingsGroup(title = stringResource(R.string.settings_updates)) {
                SettingsRow(
                    title = stringResource(R.string.settings_autoupdate),
                    description = stringResource(R.string.settings_autoupdate_desc),
                    icon = Icons.Rounded.CloudSync,
                    trailing = {
                        Switch(
                            checked = state.settings.autoUpdateCheck,
                            onCheckedChange = { v -> vm.updateSettings { it.copy(autoUpdateCheck = v) } },
                        )
                    },
                )
                SettingsDivider()
                SettingsRow(
                    title = stringResource(R.string.settings_beta_channel),
                    description = stringResource(R.string.settings_beta_channel_desc),
                    icon = Icons.Rounded.Science,
                    trailing = {
                        Switch(
                            checked = state.settings.betaChannel,
                            onCheckedChange = { v ->
                                vm.updateSettings { it.copy(betaChannel = v) }
                                // канал переключили — пересмотреть обновления честно
                                vm.checkForUpdate(manual = false)
                            },
                        )
                    },
                )
                SettingsDivider()
                SettingsRow(
                    title = stringResource(R.string.settings_check_update),
                    description = state.appUpdate?.let {
                        stringResource(R.string.update_version, it.versionName)
                    },
                    icon = Icons.Rounded.SystemUpdate,
                    onClick = { vm.checkForUpdate(manual = true) },
                    trailing = {
                        Icon(
                            Icons.AutoMirrored.Rounded.KeyboardArrowRight, null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    },
                )
            }

            // ── Сообщество ──
            SettingsGroup {
                RepoRow(
                    title = stringResource(R.string.about_tg_channel),
                    url = "https://t.me/${TELEGRAM_CHANNEL}",
                    icon = Icons.AutoMirrored.Rounded.Send,
                )
                RepoRow(
                    title = "GhostLock 原作者 YuKongA",
                    url = "https://github.com/YuKongA/ghostlock-app",
                    icon = Icons.AutoMirrored.Rounded.Send,
                )
                RepoRow(
                    title = "无痕一键root 作者：酷安 @寂寞夜无痕",
                    url = "https://www.coolapk.com/search?q=%E5%AF%82%E5%AF%9E%E5%A4%9C%E6%97%A0%E7%97%95",
                    icon = Icons.AutoMirrored.Rounded.Send,
                )
                RepoRow(
                    title = "RootMyVivo 作者 zenyxx-xd",
                    url = "https://github.com/zenyxx-xd/RootMyVivo",
                    icon = Icons.AutoMirrored.Rounded.Send,
                )
                RepoRow(
                    title = "整合 / 打包：酷安 @依然饭后吸",
                    url = "https://www.coolapk.com/u/28045880",
                    icon = Icons.AutoMirrored.Rounded.Send,
                )

            }

            // ── Репозитории ──
            SettingsGroup(title = stringResource(R.string.about_repositories)) {
                RepoRow(
                    title = stringResource(R.string.about_repo_app),
                    url = REPO_APP,
                    icon = Icons.Rounded.Code,
                )
                SettingsDivider()
                RepoRow(
                    title = stringResource(R.string.about_repo_payloads),
                    url = REPO_PAYLOADS,
                    icon = Icons.Rounded.CloudDownload,
                )
                SettingsDivider()
                RepoRow(
                    title = stringResource(R.string.about_repo_exploit),
                    url = REPO_EXPLOIT,
                    icon = Icons.Rounded.Bolt,
                )
            }

            // ── Дисклеймер ──
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
            ) {
                Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Rounded.Warning, null, tint = MaterialTheme.colorScheme.onErrorContainer)
                    Column {
                        Text(
                            stringResource(R.string.disclaimer_title),
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            stringResource(R.string.disclaimer_text),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.85f),
                        )
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun RepoRow(title: String, url: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    val context = LocalContext.current
    SettingsRow(
        title = title,
        description = url.removePrefix("https://"),
        icon = icon,
        onClick = { openUrl(context, url) },
        trailing = {
            Icon(
                Icons.AutoMirrored.Rounded.OpenInNew, null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp),
            )
        },
    )
}
