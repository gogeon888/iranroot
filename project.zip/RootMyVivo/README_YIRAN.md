# 依然一键root 整合版（基于 RootMyVivo 外壳 + GhostLock 引擎 + 无痕一键root 载荷链）

本仓库是 **RootMyVivo** 的整合改造版：保留它全部外壳能力，并**内置**一条已经过真机验证的提权链，
使 **vivo S18 Pro（PD2344 / MT6985 / 内核 5.15.149-android13-8-gf81de23b360f-dirty）** 开箱可用。

## 内置链做了什么（与原通道并存，失败自动回落）

| 阶段 | 组件 | 作用 |
|---|---|---|
| 引擎 | `libglk_engine.so`（= GhostLock 引擎，已注入脚本） | W1：把 `selinux_state.enforcing` 写成 0（SELinux→Permissive）+ 建内核 root 通道 `atcid_vendor_socket` |
| 看门狗 | 本 App（`GlkChain`） | 轮询到引擎生成的 `.ghostlock_root.sh` 就立刻执行 —— **所以引擎自己卡死在 W2 也完全不影响结果** |
| 越狱 | 脚本内的无痕载荷链 `libwk_*.so` | `c1`：`ksud late-load --allow-shell` + 激活 KernelSU 越狱模式；随后修 ashmem |
| 验收 | 脚本打印的 `===== verify =====` | `uid=0` / `Permissive` / `kernelsu=1` 三项，App 只认这一段（shell 读不了 /proc/modules） |
| 收尾 | 脚本 | 发通知 → 杀卡死引擎 → 用 shell 身份五次拉起 KernelSU → 干净收尾 |

## 关键设计（踩过坑，改代码前请先看）

1. **脚本里的 `%` 必须严格 4 个**（`%s %s %d %s`）—— 引擎把模板当格式串；多一个（例如写 `date +%s`）会让它越界崩溃，
   现象是：引擎日志打印完配置就停、`.ghostlock_root.sh` 变成 **0 字节**。
   自检：`grep -o '%' app/src/main/assets/glk/combined_root.sh | wc -l` → 4。
2. **脚本不要由 App 推送** —— asset 里那份是带占位符的**模板**，真正的脚本由**引擎自己生成**（路径 `/data/local/tmp/ghostlock-app/.ghostlock_root.sh`）。
3. **shell 通道三级回退**：ADB 已固定（首次成功后 `persistAfterRoot` 固定 5555）→ 无线调试直连（`AdbWire`，允许弹授权框）→ 报错并提示用户。
4. **成功判定只读 verify 段**：`Transport.exec` 是 **shell 域（uid=2000）**，永远拿不到 `uid=0`；`/proc/modules` 也只有 root 能读。
5. 载体全部放 `app/src/main/jniLibs/arm64-v8a/lib*.so`（与原仓库的 `libbootstrap.so`/`libdfroot.so` 同一套路），
   shell 可从 `/data/app/…/lib/arm64/` 直接 `cp`，**不需要 ADB push**。

## 构建

```sh
./gradlew :app:assembleDebug      # 或 assembleRelease（需自备签名）
```
CI：本仓库自带 `.github/workflows/build.yml`，在 Actions 里 **Run workflow** 即可产出 Debug APK（无需本地 SDK）。

## 署名（底层全部归原作者）

- **GhostLock 原作者：YuKongA** — https://github.com/YuKongA/ghostlock-app
- **无痕一键root 作者：酷安 @寂寞夜无痕**
- **RootMyVivo 作者：zenyxx-xd** — https://github.com/zenyxx-xd/RootMyVivo
- **整合 / 打包：酷安 @依然饭后吸** — https://www.coolapk.com/u/28045880

## 限制与风险（务必阅读）

- **临时 root**：重启后失效；已内置"固定 ADB 5555"，重启后可由 App 自动重跑（需要保持无线调试/ADB 通道可用）。
- **内核 panic 概率存在**：漏洞利用固有风险（作者本机实测约 12 次成功 / 1 次重启），重启后再点一次即可，不会变砖。
- 仅限**自有设备**使用；厂商 OTA 若修补该漏洞（CVE-2026-43499）则失效。
- 本项目仅做整合与适配，未改动任何原作者的提权实现。
